create view version as
select '1.5.2' AS `sys_version`, version() AS `mysql_version`;

